export const RoleActions = {
    Owner: ['All'],
    owner: ['All'],

    Manager: ['All'],
    manager: ['All'],

    'Store Manager':['Dashboard','Products','Receipts','Inventory','Petty Cash','Expense Tracking','Setup',"Notifications"],
    'store Manager':['Dashboard','Products','Receipts','Inventory','Petty Cash','Expense Tracking','Setup',"Notifications"],
    'Store manager':['Dashboard','Products','Receipts','Inventory','Petty Cash','Expense Tracking','Setup',"Notifications"],
    'store manager':['Dashboard','Products','Receipts','Inventory','Petty Cash','Expense Tracking','Setup',"Notifications"],

    Biller:['Dashboard','Sell','Receipts','Customers','Kitchen'],
    biller:['Dashboard','Sell','Receipts','Customers','Kitchen'],

    Kitchen:['Dashboard','Sell','Receipts','Customers','Kitchen'],
    kitchen:['Dashboard','Sell','Receipts','Customers','Kitchen'] 

}
